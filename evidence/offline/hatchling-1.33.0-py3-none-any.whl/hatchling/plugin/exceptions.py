class UnknownPluginError(ValueError):
    pass
